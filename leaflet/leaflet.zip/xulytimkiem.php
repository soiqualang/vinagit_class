<?php
	echo 'hahahahaha';
?>